import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { galleryConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

interface Props {
  onSelect: (id: string) => void;
}

export default function ImmersiveGallery({ onSelect }: Props) {
  const sectionRef = useRef<HTMLElement>(null);
  const textShadow = '0 2px 20px rgba(0,0,0,0.35)';
  const PROJECTS = galleryConfig.projects;

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const header = section.querySelector('.gallery-header');
      const cards = section.querySelectorAll('.gallery-card');

      if (header) {
        gsap.fromTo(header,
          { y: 40, opacity: 0 },
          {
            y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
            scrollTrigger: { trigger: header, start: 'top 80%', toggleActions: 'play none none reverse' },
          }
        );
      }

      cards.forEach((card, i) => {
        gsap.fromTo(card,
          { y: 60, opacity: 0 },
          {
            y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: i * 0.15,
            scrollTrigger: { trigger: card, start: 'top 85%', toggleActions: 'play none none reverse' },
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  if (PROJECTS.length === 0 && !galleryConfig.title) {
    return null;
  }

  return (
    <section
      ref={sectionRef}
      style={{
        position: 'relative',
        zIndex: 2,
        background: 'transparent',
        paddingTop: '15vh',
        paddingBottom: '15vh',
      }}
    >
      {/* Section header */}
      <div
        className="gallery-header"
        style={{
          padding: '0 2rem',
          marginBottom: '10vh',
        }}
      >
        <div
          className="font-sans-body"
          style={{
            fontSize: 10,
            letterSpacing: '0.25em',
            color: 'rgba(255,255,255,0.55)',
            textTransform: 'uppercase',
            marginBottom: 16,
            textShadow,
          }}
        >
          {galleryConfig.sectionLabel}
        </div>
        <h2
          className="font-serif-display"
          style={{
            fontSize: 'clamp(28px, 4vw, 48px)',
            fontWeight: 200,
            color: '#ffffff',
            letterSpacing: '0.05em',
            lineHeight: 1.2,
            margin: 0,
            textShadow,
          }}
        >
          {galleryConfig.title}
        </h2>
      </div>

      {/* Projects — asymmetric alternating layout */}
      <div
        style={{
          position: 'relative',
          padding: '0 2rem',
        }}
      >
        {PROJECTS.map((project, i) => {
          const isLeft = i % 2 === 0;
          return (
            <div
              key={project.id}
              className="gallery-card"
              style={{
                display: 'flex',
                justifyContent: isLeft ? 'flex-start' : 'flex-end',
                marginTop: i === 0 ? 0 : i === 1 ? '-55vh' : i === 2 ? '-20vh' : '-45vh',
                marginBottom: 0,
                paddingLeft: isLeft ? '5vw' : '40vw',
                paddingRight: isLeft ? '40vw' : '5vw',
              }}
            >
              <div
                style={{
                  width: '45vw',
                  maxWidth: 600,
                }}
              >
                <div
                  onClick={() => onSelect(project.id)}
                  style={{
                    width: '100%',
                    aspectRatio: '1024 / 1536',
                    position: 'relative',
                    overflow: 'hidden',
                    cursor: 'pointer',
                  }}
                >
                  <img
                    src={project.image}
                    alt={project.title}
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      display: 'block',
                      transition: 'transform 0.6s ease',
                    }}
                    loading="lazy"
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'scale(1.03)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'scale(1)';
                    }}
                  />
                </div>

                {/* Meta */}
                <div
                  style={{
                    marginTop: 24,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start',
                  }}
                >
                  <div>
                    <div
                      className="font-mono"
                      style={{
                        fontSize: 11,
                        letterSpacing: '0.2em',
                        color: 'rgba(255,255,255,0.7)',
                        textTransform: 'uppercase',
                        marginBottom: 8,
                        textShadow,
                      }}
                    >
                      {project.id}
                    </div>
                    <h3
                      className="font-serif-display"
                      onClick={() => onSelect(project.id)}
                      style={{
                        fontSize: 20,
                        fontWeight: 300,
                        color: '#ffffff',
                        letterSpacing: '0.08em',
                        margin: 0,
                        textShadow,
                        cursor: 'pointer',
                        display: 'inline-block',
                        borderBottom: '1px solid transparent',
                        transition: 'border-color 0.3s ease',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderBottomColor = 'rgba(255,255,255,0.55)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderBottomColor = 'transparent';
                      }}
                    >
                      {project.title}
                    </h3>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div
                      className="font-sans-body"
                      style={{
                        fontSize: 10,
                        letterSpacing: '0.15em',
                        color: 'rgba(255,255,255,0.6)',
                        textShadow,
                      }}
                    >
                      {project.location}
                    </div>
                    <div
                      className="font-sans-body"
                      style={{
                        fontSize: 10,
                        letterSpacing: '0.15em',
                        color: 'rgba(255,255,255,0.6)',
                        marginTop: 4,
                        textShadow,
                      }}
                    >
                      {project.year}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
