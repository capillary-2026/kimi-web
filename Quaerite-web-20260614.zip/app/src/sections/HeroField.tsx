import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { heroConfig } from '../config';

export default function HeroField() {
  const sectionRef = useRef<HTMLElement>(null);
  const textShadow = '0 2px 30px rgba(255,255,255,0.6)';

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const wordmark = section.querySelector('.hero-wordmark');
    const panel = section.querySelector('.hero-panel');
    const cta = section.querySelector('.hero-cta');

    const ctx = gsap.context(() => {
      gsap.fromTo(wordmark,
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, duration: 1.2, ease: 'power3.out', delay: 0.2 }
      );
      gsap.fromTo(panel,
        { x: 60, opacity: 0 },
        { x: 0, opacity: 1, duration: 1.0, ease: 'power3.out', delay: 0.5 }
      );
      if (cta) {
        gsap.fromTo(cta,
          { opacity: 0 },
          { opacity: 1, duration: 0.8, ease: 'power2.out', delay: 1.0 }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  if (!heroConfig.wordmarkText && !heroConfig.titleLine1) {
    return null;
  }

  return (
    <section
      ref={sectionRef}
      style={{
        position: 'relative',
        width: '100%',
        height: '100vh',
        display: 'flex',
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          flex: '1 1 auto',
          position: 'relative',
          display: 'grid',
          gridTemplateColumns: '1.4fr 1fr',
          alignItems: 'center',
          padding: '0 6vw',
          gap: '6vw',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <h2
            className="font-serif-display hero-wordmark"
            style={{
              fontSize: 'clamp(48px, 7vw, 112px)',
              fontWeight: 300,
              color: '#0B1D3A',
              letterSpacing: '0.15em',
              textShadow,
              margin: 0,
            }}
          >
            {heroConfig.wordmarkText}
          </h2>
        </div>

        <div
          className="hero-panel"
          style={{
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'flex-start',
            textAlign: 'left',
            maxWidth: '460px',
            background: 'rgba(255,255,255,0.72)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            border: '1px solid rgba(255,255,255,0.5)',
            borderRadius: '16px',
            padding: '48px 40px',
          }}
        >
          {heroConfig.eyebrow && (
            <p
              className="font-sans-body"
              style={{
                fontSize: '12px',
                letterSpacing: '0.3em',
                color: '#7A8FA6',
                textTransform: 'uppercase',
                marginBottom: '28px',
              }}
            >
              {heroConfig.eyebrow}
            </p>
          )}

          <h1
            className="font-serif-display"
            style={{
              fontSize: 'clamp(28px, 2.8vw, 44px)',
              fontWeight: 300,
              lineHeight: 1.3,
              color: '#0B1D3A',
              wordBreak: 'keep-all',
              marginBottom: '24px',
            }}
          >
            {heroConfig.titleLine1}
            {heroConfig.titleLine2 && (
              <>
                <br />
                {heroConfig.titleLine2}
              </>
            )}
          </h1>

          {(heroConfig.descriptionLine1 || heroConfig.descriptionLine2) && (
            <p
              className="font-sans-body"
              style={{
                fontSize: '14px',
                lineHeight: 1.9,
                color: '#3A5068',
                fontWeight: 300,
                marginBottom: '40px',
              }}
            >
              {heroConfig.descriptionLine1}
              {heroConfig.descriptionLine2 && (
                <>
                  <br />
                  {heroConfig.descriptionLine2}
                </>
              )}
            </p>
          )}

          {heroConfig.ctaText && (
            <button
              className="font-sans-body hero-cta"
              onClick={() => {
                if (heroConfig.ctaTargetId) {
                  document
                    .getElementById(heroConfig.ctaTargetId)
                    ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
              }}
              style={{
                background: 'transparent',
                border: '1px solid rgba(11,29,58,0.25)',
                borderRadius: '40px',
                padding: '14px 32px',
                color: '#0B1D3A',
                fontSize: '13px',
                letterSpacing: '0.15em',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(14,139,191,0.1)';
                e.currentTarget.style.borderColor = 'rgba(14,139,191,0.4)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.borderColor = 'rgba(11,29,58,0.25)';
              }}
            >
              {heroConfig.ctaText}
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
