export interface SiteConfig {
  language: string
  siteTitle: string
  siteDescription: string
}

export interface NavLink {
  label: string
  targetId: string
}

export interface NavigationConfig {
  brandMark: string
  links: NavLink[]
}

export interface HeroConfig {
  wordmarkText: string
  eyebrow: string
  titleLine1: string
  titleLine2: string
  descriptionLine1: string
  descriptionLine2: string
  ctaText: string
  ctaTargetId: string
}

export interface PhilosophyConfig {
  eyebrow: string
  title: string
  body: string
  rollingWords: string[]
}

export interface ProjectMeta {
  label: string
  value: string
}

export interface ProjectData {
  id: string
  title: string
  location: string
  year: string
  image: string
  subtitle: string
  meta: ProjectMeta[]
  paragraphs: string[]
}

export interface GalleryConfig {
  sectionLabel: string
  title: string
  projects: ProjectData[]
}

export interface MediumItem {
  cn: string
  en: string
  description: string
}

export interface MediumsConfig {
  sectionLabel: string
  items: MediumItem[]
}

export interface FooterEntry {
  text: string
  href?: string
}

export interface FooterColumn {
  heading: string
  entries: FooterEntry[]
}

export interface FooterConfig {
  visionText: string
  brandName: string
  columns: FooterColumn[]
  copyright: string
  videoPath: string
}

export interface ProjectDetailConfig {
  backLabel: string
}

export const siteConfig: SiteConfig = {
  language: "en",
  siteTitle: "Quaerite Biopharm Research",
  siteDescription: "Clinical-stage biotechnology company developing engineered, long-acting ocular biologics for vision-threatening retinal diseases.",
}

export const navigationConfig: NavigationConfig = {
  brandMark: "QB",
  links: [
    { label: "Platform", targetId: "philosophy" },
    { label: "Pipeline", targetId: "gallery" },
    { label: "Technology", targetId: "mediums" },
    { label: "Contact", targetId: "footer" },
  ],
}

export const heroConfig: HeroConfig = {
  wordmarkText: "QUAERITE",
  eyebrow: "BIOTECH FOR VISION",
  titleLine1: "Engineered Ocular",
  titleLine2: "Biologics for Retinal Disease",
  descriptionLine1: "A proprietary durability platform extending ocular drug residence time through reversible albumin complexation — without surgery, implants, or gene therapy.",
  descriptionLine2: "",
  ctaText: "EXPLORE",
  ctaTargetId: "philosophy",
}

export const philosophyConfig: PhilosophyConfig = {
  eyebrow: "PLATFORM / 001",
  title: "OcuHLE-X",
  body: "A proprietary, non-covalent albumin-complexation approach to ocular drug durability. Reversible, well-penetrating, and patient-friendly — matching the dosing intervals of devices and gene therapy without surgery or irreversibility.",
  rollingWords: ["ALBUMIN", "DURABLE", "REVERSIBLE", "PENETRATING", "INJECTABLE", "SCALABLE"],
}

export const galleryConfig: GalleryConfig = {
  sectionLabel: "PIPELINE / 002",
  title: "Clinical Programs",
  projects: [
    {
      id: "QBR202",
      title: "QBR202 — nAMD/DME",
      location: "Phase I",
      year: "2026",
      image: "images/project-1.jpg",
      subtitle: "Tri-specific nanobody — VEGF-A + Ang-2 + HSA",
      meta: [
        { label: "TARGETS", value: "VEGF-A + Ang-2 + HSA" },
        { label: "FORMAT", value: "Tri-specific nanobody (~69.4 kDa)" },
        { label: "STAGE", value: "China Phase I (active)" },
        { label: "INDICATION", value: "nAMD, DME, RVO" },
      ],
      paragraphs: [
        "QBR202 is our lead asset — a tri-specific nanobody targeting VEGF-A (2 domains), Ang-2 (1 domain), and HSA (2 domains) for extended ocular residence. First patient dosed April 13, 2026, with early signals directionally encouraging: Day 3 CST reduction of 27 μm and BCVA improvement of +5 letters.",
        "The clinical program encompasses single ascending doses (0.2, 0.5, 1.2, 2.5, 5.0 mg) with multi-dose initiation planned for April 2027. Our target product profile is a 3-month durability floor with 4-month target and 6-month upside — a meaningful advancement over current q4w-q8w standard of care.",
        "Preclinical differentiation is substantial: VEGFR2 blockade 600–1,500x more potent than Vabysmo in vitro, superior Tie-2 phosphorylation, NHP IVT bioavailability of 79.85–108.39%, and retina/choroid concentration ~3x vs. Vabysmo in humanized mice at Day 7. FDA IND cleared December 2025 with zero CMC questions.",
        "Partnership posture: Retain China rights; open to ex-China co-development and licensing structures. Partner engagement now allows influence on dose strategy, Phase Ib/II design, and comparator choice ahead of the 2026 durability readout that defines our central valuation inflection point.",
      ],
    },
    {
      id: "QBR207",
      title: "QBR207 — GA",
      location: "Preclinical",
      year: "2026",
      image: "images/project-2.jpg",
      subtitle: "Multi-specific nanobody — C3 + C5 + HSA",
      meta: [
        { label: "TARGETS", value: "C3 + C5 + HSA" },
        { label: "FORMAT", value: "Multi-specific nanobody (~70 kDa)" },
        { label: "STAGE", value: "IND-enabling / preclinical" },
        { label: "INDICATION", value: "Geographic Atrophy (GA)" },
      ],
      paragraphs: [
        "QBR207 targets Geographic Atrophy through dual upstream C3 and terminal C5 blockade, suppressing C3a/C5a, C3b deposition, and macrophage IL-6/TNF-α/IL-1β release. This mechanism offers potentially more complete complement suppression than C5-only agents like Syfovre and Izervay.",
        "Preclinical potency is compelling: 2–13x more potent than Syfovre/Izervay on C3a, C5a, and C3b deposition in vitro. The primate blue-light GA model is planned for November 2026, which will unlock partnership conversations with potential co-development partners.",
        "The GA market is newly treatable but still unsatisfied — existing therapies show modest efficacy and safety has been debated. QBR207 enters a validated market whose incumbents have left the efficacy bar low. Dual C3/C5 inhibition may provide the more complete complement suppression that patients and physicians need.",
        "Strategic positioning: QBR207 is structured for risk-shared co-development. Ex-China partnering value is estimated at $250M–$450M (base case) with headline deal economics of $40M–$75M upfront, $500M–$900M milestones, and mid-teens royalties.",
      ],
    },
    {
      id: "QBR209",
      title: "QBR209 — Trispecific",
      location: "Preclinical",
      year: "2027",
      image: "images/project-3.jpg",
      subtitle: "Global first-in-class trispecific nanobody",
      meta: [
        { label: "TARGETS", value: "Trispecific (undisclosed)" },
        { label: "FORMAT", value: "Trispecific nanobody" },
        { label: "STAGE", value: "Early preclinical" },
        { label: "INDICATION", value: "Retinal diseases" },
      ],
      paragraphs: [
        "QBR209 is a global first-in-class trispecific nanobody with no direct competitor in global databases as of March 2026. This program represents the frontier of multi-specific ocular biologics, combining three therapeutic mechanisms in a single compact nanobody format.",
        "The trispecific format builds on our OcuHLE-X durability platform, inheriting the same reversible albumin-complexation backbone that has demonstrated 206–243 hour ocular half-life in rabbits. The modular architecture allows rapid format iteration and target optimization.",
        "Strategic posture: High internal risk; explicitly held for partner-led development rather than solo funding. This contributes platform optionality and global-first positioning to our pipeline narrative. A partner with complementary expertise can accelerate development while sharing risk.",
      ],
    },
    {
      id: "QBR211",
      title: "QBR211 — TED",
      location: "Discovery",
      year: "2028",
      image: "images/project-4.jpg",
      subtitle: "Thyroid eye disease modality evaluation",
      meta: [
        { label: "TARGETS", value: "Multi-specific (TED)" },
        { label: "FORMAT", value: "Multi-specific nanobody" },
        { label: "STAGE", value: "Modality selection" },
        { label: "INDICATION", value: "Thyroid Eye Disease" },
      ],
      paragraphs: [
        "QBR211 extends our OcuHLE-X platform beyond retinal vascular disease and GA into Thyroid Eye Disease (TED) — a debilitating autoimmune condition with significant unmet need. TED modality evaluation is underway to determine the optimal multi-specific format for this indication.",
        "The TED opportunity represents a natural expansion of our platform into adjacent ophthalmology indications where durable, reversible biologic therapy can transform patient outcomes. Our nanobody format's small size, multi-specific capability, and manufacturability make it well-suited for this indication.",
        "Early discovery work is evaluating target combinations and potency requirements. Program progression is gated on modality selection data and partnership interest. This program adds optionality and demonstrates the breadth of our platform's applicability.",
      ],
    },
  ],
}

export const mediumsConfig: MediumsConfig = {
  sectionLabel: "TECHNOLOGY / 003",
  items: [
    {
      cn: "Core",
      en: "PLATFORM",
      description: "OcuHLE-X is our proprietary durability platform using reversible albumin complexation to extend ocular drug residence time. The non-covalent approach achieves ~185 kDa complex size with preserved tissue penetration — no surgery, no implants, no gene therapy irreversibility.",
    },
    {
      cn: "Build",
      en: "PIPELINE",
      description: "Our modular multi-specific nanobody format enables simultaneous blockade of multiple disease drivers in a compact ~69–70 kDa scaffold. Each new program inherits a de-risked delivery and CMC foundation, accelerating development timelines and reducing risk.",
    },
    {
      cn: "Shield",
      en: "PATENTS",
      description: "Six core patent families protect our platform and pipeline: 2 granted and 9 pending across anti-VEGFA nanobody, anti-HSA nanobody (OcuHLE-X keystone), fusion constructs, anti-ANG2 multispecifics, and complement C3/C3b epitope technologies. PCT filings in China, US, Europe, Japan, Canada, and Australia.",
    },
    {
      cn: "Scale",
      en: "MANUFACTURING",
      description: "Standard recombinant CHO expression with >5 g/L titer, >90% yield, concentrated liquid formulation at 50 mg/mL, and 30G needle compatibility. Built for cost-efficient, scalable supply. Zero CMC questions from FDA at IND clearance.",
    },
  ],
}

export const footerConfig: FooterConfig = {
  visionText: "We believe that controlling retinal disease with fewer injections — without trading safety or efficacy — is the defining challenge in ophthalmology. Our mission is to make long-acting, reversible ocular biologics the new standard of care.",
  brandName: "QUAERITE",
  columns: [
    {
      heading: "CONTACT",
      entries: [
        { text: "2/F, Building C9, Yiyuan\nNo. 65 Xingshikou Road\nHaidian District, Beijing 100093\nChina" },
        { text: "+86 10 6994 5859", href: "tel:+861069945859" },
        { text: "info@quaerite.com", href: "mailto:info@quaerite.com" },
        { text: "LinkedIn", href: "https://linkedin.com/company/quaerite" },
      ],
    },
    {
      heading: "INVESTORS",
      entries: [
        { text: "Morningside (Lead)" },
        { text: "3E Bio" },
        { text: "Alwin / Yahui" },
        { text: "Bohe" },
      ],
    },
    {
      heading: "CATALYSTS",
      entries: [
        { text: "QBR202 Phase I durability readout — 2026" },
        { text: "Round C close — Q2–Q3 2026" },
        { text: "QBR207 primate GA model — ~Nov 2026" },
        { text: "MAD initiation — April 2027" },
      ],
    },
  ],
  copyright: "© 2026 Quaerite Biopharm Research. All rights reserved.",
  videoPath: "videos/footer.mp4",
}

export const projectDetailConfig: ProjectDetailConfig = {
  backLabel: "← BACK",
}

export function getProjectById(id: string): ProjectData | undefined {
  return galleryConfig.projects.find((p) => p.id === id)
}
