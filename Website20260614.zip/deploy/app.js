/* app.js — Quaerite Biopharm Research */
(function () {
  'use strict';

  /* ── DATA ── */
  const RING_WORDS = ['ALBUMIN','DURABLE','REVERSIBLE','PENETRATING','INJECTABLE','SCALABLE'];

  const PROJECTS = [
    { id:'QBR202', title:'QBR202 — nAMD/DME', stage:'Phase I', year:'2026',
      image:'assets/images/qbr202.png',
      subtitle:'Tri-specific nanobody — VEGF-A + Ang-2 + HSA',
      meta:[{l:'TARGETS',v:'VEGF-A + Ang-2 + HSA'},{l:'FORMAT',v:'Tri-specific nanobody (~69.4 kDa)'},{l:'STAGE',v:'China Phase I (active)'},{l:'INDICATION',v:'nAMD, DME, RVO'}],
      body:['QBR202 is our lead asset — a tri-specific nanobody targeting VEGF-A, Ang-2, and HSA for extended ocular residence. Phase I was initiated in April 2026.',
            'The clinical program encompasses single ascending doses with multi-dose initiation planned for 2027. Our target product profile is a 3-month durability floor with 4-month target and 6-month upside — a meaningful advancement over current q4w–q8w standard of care.',
            'Preclinical differentiation is substantial: VEGFR2 exhibits meaningfully potent blockade compared with SoC (Standard of Care) in vitro, superior Tie-2 phosphorylation, NHP IVT bioavailability of 79.85–108.39%, and desirable retina/choroid concentration. FDA IND cleared December 2025 with zero CMC questions.']},
    { id:'QBR207', title:'QBR207 — GA', stage:'Preclinical', year:'2026',
      image:'assets/images/project-2.jpg',
      subtitle:'Multi-specific nanobody — C3 + C5 + HSA',
      meta:[{l:'TARGETS',v:'C3 + C5 + HSA'},{l:'FORMAT',v:'Multi-specific nanobody (~70 kDa)'},{l:'STAGE',v:'IND-enabling / preclinical'},{l:'INDICATION',v:'Geographic Atrophy (GA)'}],
      body:['QBR207 targets Geographic Atrophy through dual upstream C3 and terminal C5 blockade, suppressing C3a/C5a, C3b deposition, and macrophage IL-6/TNF-α/IL-1β release. This mechanism offers potentially more complete complement suppression than C5-only agents.',
            'Preclinical potency is compelling: much more potent than Syfovre/Izervay on C3a, C5a, and C3b deposition in vitro. The primate blue-light GA model is planned for November 2026, unlocking partner conversations.',
            'The GA market is newly treatable but still unsatisfied — existing therapies show modest efficacy. QBR207 enters a validated market with a low incumbency bar.']},
    { id:'QBR209', title:'QBR209', stage:'Preclinical', year:'2027',
      image:'assets/images/qbr209.webp',
      subtitle:'Global first-in-class trispecific nanobody',
      meta:[{l:'TARGETS',v:'Trispecific (undisclosed)'},{l:'FORMAT',v:'Trispecific nanobody'},{l:'STAGE',v:'PCC confirmation'},{l:'INDICATION',v:'Retinal diseases'}],
      body:['QBR209 is a global first-in-class trispecific nanobody with no direct competitor in global databases as of March 2026, representing the frontier of multi-specific ocular biologics.',
            'The trispecific format builds on our OcuHLE-X durability platform, inheriting the same reversible albumin-complexation backbone that has demonstrated 206–243 hour ocular half-life in rabbits.']},
    { id:'QBR211', title:'QBR211 — TED', stage:'Discovery', year:'2028',
      image:'assets/images/project-4.jpg',
      subtitle:'Thyroid eye disease modality evaluation',
      meta:[{l:'TARGETS',v:'Multi-specific (TED)'},{l:'FORMAT',v:'Multi-specific nanobody'},{l:'STAGE',v:'PCC confirmation'},{l:'INDICATION',v:'Thyroid Eye Disease'}],
      body:['QBR211 extends our OcuHLE-X platform beyond retinal vascular disease into Thyroid Eye Disease — a debilitating autoimmune condition with significant unmet need.',
            'The TED opportunity represents a natural expansion of our platform into adjacent ophthalmology indications where durable, reversible biologic therapy can transform patient outcomes.',
            'Early discovery work is evaluating target combinations and potency requirements. Program progression is gated on modality selection data and partnership interest.']},
  ];

  const MEDIUMS = [
    { cn:'Core', en:'PLATFORM', desc:'OcuHLE-X is our proprietary durability platform using reversible albumin complexation to extend ocular drug residence time. The non-covalent approach achieves ~185 kDa complex size with preserved tissue penetration — no surgery, no implants, no gene therapy irreversibility.' },
    { cn:'Build', en:'PIPELINE', desc:'Our modular multi-specific nanobody format enables simultaneous blockade of multiple disease drivers in a compact ~69–70 kDa scaffold. Each new program inherits a de-risked delivery and CMC foundation, accelerating development timelines and reducing risk.' },
    { cn:'Shield', en:'PATENTS', desc:'Six core patent families protect our platform and pipeline: 2 granted and 9 pending across anti-VEGFA nanobody, anti-HSA nanobody (OcuHLE-X keystone), fusion constructs, anti-ANG2 multispecifics, and complement C3/C3b epitope technologies. PCT filings in China, US, Europe, Japan, Canada, and Australia.' },
    { cn:'Scale', en:'MANUFACTURING', desc:'Standard recombinant CHO expression with >5 g/L titer, >90% yield, concentrated liquid formulation at 50 mg/mL, and 30G needle compatibility. Built for cost-efficient, scalable supply. Zero CMC questions from FDA at IND clearance.' },
  ];

  const TEAM = [
    { initials:'FQ', name:'Prof. Feng QIAN', role:'Founder, SAB Chair',
      photo:'assets/images/team/feng-qian.jpg',
      grad:'linear-gradient(140deg,#091E38 0%,#0E4D6E 55%,#30B0D0 100%)',
      bio:'Dean of Tsinghua University’s School of Pharmaceutical Sciences and an expert in drug delivery. Previously spent approximately ten years at Bristol Myers Squibb; provides the scientific foundation for Quaerite’s platforms.' },
    { initials:'LC', name:'Dr. Li CHEN', role:'Chief Technology Officer',
      photo:'assets/images/team/li-chen.jpg',
      grad:'linear-gradient(140deg,#061018 0%,#0A3A58 55%,#1A9EC0 100%)',
      bio:'Biopharmaceutical R&D leader with more than 20 years of experience in antibody discovery, development and commercialization, including contributions to two marketed drugs.' },
    { initials:'XQZ', name:'Xiaoqing ZHU', role:'Co-founder, Chief Operating Officer',
      photo:'assets/images/team/xiaoqing-zhu.jpg',
      grad:'linear-gradient(140deg,#0B2030 0%,#0E4060 55%,#30B0D0 100%)',
      bio:'Life-science executive with over ten years of international management and operational experience, including leadership roles at Novozymes/Novonesis. Oversees corporate operations and organizational development.' },
    { initials:'LL', name:'Lei LIU', role:'VP, Business Development & Strategy',
      photo:'assets/images/team/lei-liu.jpg',
      grad:'linear-gradient(140deg,#061018 0%,#0B3050 55%,#1A7BA0 100%)',
      bio:'Leads Quaerite’s corporate strategy, financing and business-development activities, including global partnerships and external engagement around the company’s pipeline.' },
  ];

  const ADVISORS = [
    { initials:'TYW', name:'Prof. Tien Yin Wong', role:'Lead Scientific Advisor', photo:'assets/images/team/advisor-ty-wong.jpg',
      bio:'Internationally recognized retinal specialist and clinician-scientist. Member of the Singapore National Academy of Science and foreign member of the US National Academy of Medicine. Advises Quaerite on retinal medicine and clinical strategy.' },
    { initials:'HH', name:'Henry HSU, MD', role:'Scientific Advisor', photo:'assets/images/team/advisor-henry-hsu.jpg',
      bio:'Physician-executive with approximately 25 years of drug-development experience. Advises Quaerite on translational development, clinical strategy and advancement of innovative therapeutics.' },
    { initials:'BX', name:'Prof. Bailong XIAO', role:'Scientific Advisor', photo:'assets/images/team/advisor-bl-xiao.jpg',
      bio:'Tenured professor and New Cornerstone Investigator at Tsinghua University, specializing in mechanosensation and PIEZO ion channels. Trained at the University of Calgary and completed postdoctoral research with Nobel laureate Ardem Patapoutian at Scripps Research. His work has established key mechanisms linking mechanical stimuli to cellular electrical signals and physiological functions. Published extensively in Nature and Neuron; recipient of major national and Beijing science awards.' },
  ];


  /* ── DOM BUILDERS ── */
  function buildGallery() {
    const container = document.getElementById('gallery-cards');
    if (!container) return;
    PROJECTS.forEach((p, i) => {
      const isLeft = i % 2 === 0;
      const margTop = [0, '-55vh', '-20vh', '-45vh'][i] || 0;
      const card = document.createElement('div');
      card.className = 'g-card';
      card.style.cssText = `display:flex;justify-content:${isLeft?'flex-start':'flex-end'};
        margin-top:${margTop};
        padding-left:${isLeft?'5vw':'40vw'};
        padding-right:${isLeft?'40vw':'5vw'};
        opacity:0;transform:translateY(60px)`;
      card.innerHTML = `
        <div style="width:45vw;max-width:600px">
          <div class="g-img-wrap" data-id="${p.id}" style="width:100%;aspect-ratio:1024/1536;overflow:hidden;cursor:pointer">
            <img src="${p.image}" alt="${p.title}" loading="lazy"
              style="width:100%;height:100%;object-fit:cover;display:block;transition:transform .6s ease">
          </div>
          <div style="margin-top:24px;display:flex;justify-content:space-between;align-items:flex-start">
            <div>
              <div class="mono" style="font-size:11px;letter-spacing:.2em;color:rgba(255,255,255,.7);text-transform:uppercase;margin-bottom:8px;text-shadow:0 2px 20px rgba(0,0,0,.35)">${p.id}</div>
              <div class="g-title serif" data-id="${p.id}" style="font-size:20px;font-weight:300;color:#fff;letter-spacing:.08em;cursor:pointer;text-shadow:0 2px 20px rgba(0,0,0,.35);border-bottom:1px solid transparent;transition:border-color .3s">${p.title}</div>
            </div>
            <div style="text-align:right">
              <span style="display:block;font-size:10px;letter-spacing:.15em;color:rgba(255,255,255,.6);text-shadow:0 2px 20px rgba(0,0,0,.35)">${p.stage}</span>
              <span style="display:block;font-size:10px;letter-spacing:.15em;color:rgba(255,255,255,.6);margin-top:4px;text-shadow:0 2px 20px rgba(0,0,0,.35)">${p.year}</span>
            </div>
          </div>
        </div>`;
      container.appendChild(card);
    });
    container.querySelectorAll('.g-img-wrap img').forEach(img => {
      img.addEventListener('mouseenter', () => { img.style.transform = 'scale(1.03)'; });
      img.addEventListener('mouseleave', () => { img.style.transform = 'scale(1)'; });
    });
    container.querySelectorAll('.g-title').forEach(el => {
      el.addEventListener('mouseenter', () => { el.style.borderBottomColor = 'rgba(255,255,255,.55)'; });
      el.addEventListener('mouseleave', () => { el.style.borderBottomColor = 'transparent'; });
    });
  }

  function buildMediums() {
    const left = document.getElementById('mediums-list');
    const desc = document.getElementById('mediums-desc');
    if (!left || !desc) return;
    MEDIUMS.forEach((m, idx) => {
      const fid = `goo-${idx}`;
      const row = document.createElement('div');
      row.className = 'goo-row';
      row.style.cssText = 'cursor:pointer;border-bottom:1px solid rgba(255,255,255,.08);padding:28px 0;transition:border-color .4s;opacity:0;transform:translateX(-30px)';
      row.innerHTML = `<svg viewBox="0 0 400 50" style="width:100%;max-width:500px;height:50px;overflow:visible" preserveAspectRatio="xMinYMid meet">
        <defs><filter id="${fid}">
          <feGaussianBlur in="SourceGraphic" stdDeviation="0" result="blur" id="blur-${idx}"/>
          <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 16 -7" result="goo"/>
          <feComposite in="SourceGraphic" in2="goo" operator="atop"/>
        </filter></defs>
        <g class="tg-${idx}">
          <text class="t1-${idx}" x="0" y="35" fill="#EDE8E4"
            font-family="'Noto Serif SC',Georgia,serif" font-size="32" font-weight="300" letter-spacing="0.08em">${m.cn}</text>
          <text class="t2-${idx}" x="0" y="35" fill="#30B0D0"
            font-family="'Noto Sans SC',Helvetica,sans-serif" font-size="28" font-weight="700" letter-spacing="0.12em" opacity="0">${m.en}</text>
        </g></svg>`;
      left.appendChild(row);

      const t1 = row.querySelector(`.t1-${idx}`);
      const t2 = row.querySelector(`.t2-${idx}`);
      const tg = row.querySelector(`.tg-${idx}`);
      const feBlur = row.querySelector(`#blur-${idx}`);
      const blurProxy = { val: 0 };
      let tl = null;

      function buildTl() {
        tl = gsap.timeline({ paused: true,
          onComplete: () => { tg.style.filter = 'none'; },
          onReverseComplete: () => { tg.style.filter = 'none'; },
          onUpdate: () => { feBlur && feBlur.setAttribute('stdDeviation', String(blurProxy.val)); }
        });
        tl.to(blurProxy, { val: 1.5, duration: .5, ease: 'none' }, 0)
          .to(blurProxy, { val: 0, duration: .5, ease: 'none' }, .5)
          .to(t1, { opacity: 0, x: 8, duration: 1, ease: 'none' }, 0)
          .to(t2, { opacity: 1, x: 0, duration: 1, ease: 'power2.inOut', startAt: { x: -8 } }, 0);
      }
      buildTl();

      row.addEventListener('mouseenter', () => {
        tg.style.filter = `url(#${fid})`;
        tl.play();
        desc.querySelector('.d-label').textContent = m.en;
        desc.querySelector('.d-text').textContent = m.desc;
        desc.classList.add('visible');
      });
      row.addEventListener('mouseleave', () => {
        tg.style.filter = `url(#${fid})`;
        tl.reverse();
        desc.classList.remove('visible');
      });
    });
  }

  function buildTeam() {
    const grid = document.getElementById('team-grid');
    if (!grid) return;
    TEAM.forEach(m => {
      const card = document.createElement('div');
      card.className = 'team-card';
      card.style.cssText = 'opacity:0;transform:translateY(40px)';
      card.innerHTML = `
        <div style="width:100%;aspect-ratio:3/4;overflow:hidden;margin-bottom:24px;background:${m.grad}">
          ${m.photo
            ? `<img src="${m.photo}" alt="${m.name}" style="width:100%;height:100%;object-fit:cover;object-position:center top;display:block;filter:brightness(0.97)">`
            : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center"><span style="font-family:'Noto Serif SC',Georgia,serif;font-size:48px;font-weight:200;color:rgba(237,232,228,.55);letter-spacing:.05em">${m.initials}</span></div>`
          }
        </div>
        <div style="font-family:'Noto Serif SC',Georgia,serif;font-size:17px;font-weight:300;color:#0B1D3A;letter-spacing:.05em;margin-bottom:6px">${m.name}</div>
        <div style="font-size:10px;letter-spacing:.22em;color:#30B0D0;text-transform:uppercase;margin-bottom:12px">${m.role}</div>
        <div style="font-size:13px;line-height:1.8;color:#7A8FA6;font-weight:300">${m.bio}</div>`;
      grid.appendChild(card);
    });
  }


  function buildAdvisors() {
    const grid = document.getElementById('advisor-grid');
    if (!grid) return;
    ADVISORS.forEach(a => {
      const card = document.createElement('div');
      card.className = 'advisor-card';
      card.style.cssText = 'opacity:0;transform:translateY(40px)';
      card.innerHTML = `
        <div style="width:100%;aspect-ratio:3/4;overflow:hidden;margin-bottom:24px;
          background:linear-gradient(140deg,#0B2A42 0%,#0E5A7A 55%,#30B0D0 100%)">
          ${a.photo
            ? `<img src="${a.photo}" alt="${a.name}" style="width:100%;height:100%;object-fit:cover;object-position:center top;display:block;filter:brightness(0.97)">`
            : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center">
                <span style="font-family:'Noto Serif SC',Georgia,serif;font-size:48px;font-weight:200;color:rgba(237,232,228,.55);letter-spacing:.05em">${a.initials}</span>
              </div>`
          }
        </div>
        <div style="font-family:'Noto Serif SC',Georgia,serif;font-size:17px;font-weight:300;color:#0B1D3A;letter-spacing:.05em;margin-bottom:6px">${a.name}</div>
        <div style="font-size:10px;letter-spacing:.22em;color:#30B0D0;text-transform:uppercase;margin-bottom:12px">${a.role}</div>
        <div style="font-size:13px;line-height:1.8;color:#7A8FA6;font-weight:300">${a.bio}</div>`;
      grid.appendChild(card);
    });
  }

  /* ── INIT ── */
  let lenis = null;

  function scrollTo(id) {
    const el = document.getElementById(id);
    if (!el) return;
    if (lenis) {
      lenis.scrollTo(el, { offset: 0, duration: 1.2 });
    } else {
      const top = el.getBoundingClientRect().top + window.scrollY;
      window.scrollTo({ top: top, behavior: 'smooth' });
    }
  }

  function init() {
    buildGallery();
    buildMediums();
    buildTeam();
    buildAdvisors();

    gsap.registerPlugin(ScrollTrigger);

    /* Lenis */
    if (typeof Lenis !== 'undefined') {
      lenis = new Lenis({ lerp: 0.05 });
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(t => lenis.raf(t * 1000));
      gsap.ticker.lagSmoothing(0);
    }

    /* Nav scroll + dark/light state */
    const nav = document.getElementById('main-nav');
    const darkSections = ['mediums','footer'];
    const gallerySec = document.getElementById('gallery');
    function updateNav() {
      if (scrollY <= 80) { nav.classList.remove('scrolled','dark'); return; }
      // Determine which section is dominant in the viewport
      let isDark = false;
      darkSections.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        const r = el.getBoundingClientRect();
        if (r.top <= 60 && r.bottom > 60) isDark = true;
      });
      // Gallery is transparent over fluid bg — treat as dark
      if (gallerySec) {
        const r = gallerySec.getBoundingClientRect();
        if (r.top <= 60 && r.bottom > 60) isDark = true;
      }
      nav.classList.toggle('dark', isDark);
      nav.classList.toggle('scrolled', !isDark);
    }
    window.addEventListener('scroll', updateNav, { passive: true });
    updateNav();

    /* Nav clicks */
    document.querySelectorAll('[data-target]').forEach(btn => {
      btn.addEventListener('click', () => scrollTo(btn.dataset.target));
    });

    /* Hero entrance */
    gsap.to('.hero-wordmark', { y: 0, opacity: 1, duration: 1.2, ease: 'power3.out', delay: 0.2 });
    gsap.to('.hero-panel', { x: 0, opacity: 1, duration: 1.0, ease: 'power3.out', delay: 0.5 });
    gsap.to('.hero-cta', { opacity: 1, duration: 0.8, ease: 'power2.out', delay: 1.0 });

    /* Philosophy 3D ring */
    const ring = document.getElementById('ring-3d');
    if (ring) {
      const allWords = [...RING_WORDS, ...RING_WORDS];
      const R = 280, step = 360 / allWords.length;
      ring.style.height = R * 2 + 'px';
      allWords.forEach((w, i) => {
        const item = document.createElement('div');
        item.dataset.ringItem = '';
        item.style.cssText = `position:absolute;width:100%;text-align:center;left:0;top:50%;
          transform:rotateX(${i * step}deg) translateZ(${R}px) translateY(-50%);
          backface-visibility:hidden;will-change:filter`;
        const span = document.createElement('span');
        span.textContent = w;
        span.style.cssText = `display:inline-block;font-family:'Noto Serif SC',Georgia,serif;
          font-size:clamp(42px,8vw,100px);font-weight:300;color:#0B1D3A;
          letter-spacing:.06em;line-height:1.1;will-change:transform`;
        item.appendChild(span);
        ring.appendChild(item);
      });

      const rot = { v: 0 }, spd = { v: 0 };
      let cur = 0, curSpd = 0;

      gsap.to(rot, {
        v: 360, ease: 'none',
        scrollTrigger: {
          trigger: '#philosophy', start: 'top bottom', end: 'bottom top', scrub: 1,
          onUpdate: self => { spd.v = self.getVelocity() * 0.0003; }
        }
      });

      (function ringLoop() {
        requestAnimationFrame(ringLoop);
        cur += (rot.v - cur) * 0.08;
        curSpd += (spd.v - curSpd) * 0.1;
        spd.v *= 0.95;
        const abs = Math.abs(curSpd);
        ring.style.transform = `rotateX(${cur}deg)`;
        ring.querySelectorAll('[data-ring-item]').forEach(item => {
          const bl = Math.min(abs * 1.5, 2);
          item.style.filter = bl > 0.1 ? `blur(${bl}px)` : 'none';
          const sp = item.querySelector('span');
          if (sp) {
            const sk = Math.min(abs * 12, 10) * (curSpd > 0 ? 1 : -1);
            const sx = 1 + Math.min(abs * 0.2, 0.12);
            sp.style.transform = `skewX(${sk}deg) scaleX(${sx})`;
          }
        });
      }());
    }

    /* Gallery header entrance */
    gsap.fromTo('.gallery-header', { y: 40, opacity: 0 }, {
      y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
      scrollTrigger: { trigger: '.gallery-header', start: 'top 80%', toggleActions: 'play none none reverse' }
    });

    /* Gallery cards entrance */
    document.querySelectorAll('#gallery-cards .g-card').forEach((card, i) => {
      gsap.fromTo(card, { y: 60, opacity: 0 }, {
        y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: i * 0.15,
        scrollTrigger: { trigger: card, start: 'top 85%', toggleActions: 'play none none reverse' }
      });
    });

    /* About section entrance */
    gsap.fromTo('.about-sticky', { y: 30, opacity: 0 }, {
      y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
      scrollTrigger: { trigger: '#about', start: 'top 75%', toggleActions: 'play none none reverse' }
    });
    document.querySelectorAll('.timeline-item').forEach((item, i) => {
      gsap.fromTo(item, { x: 24, opacity: 0 }, {
        x: 0, opacity: 1, duration: 0.6, ease: 'power3.out', delay: 0.1 + i * 0.12,
        scrollTrigger: { trigger: '#about', start: 'top 75%', toggleActions: 'play none none reverse' }
      });
    });

    /* Mediums rows entrance */
    document.querySelectorAll('.goo-row').forEach((row, i) => {
      gsap.fromTo(row, { x: -30, opacity: 0 }, {
        x: 0, opacity: 1, duration: 0.6, ease: 'power3.out', delay: 0.1 + i * 0.1,
        scrollTrigger: { trigger: '#mediums', start: 'top 75%', toggleActions: 'play none none reverse' }
      });
    });

    /* Team cards entrance */
    document.querySelectorAll('.team-card').forEach((card, i) => {
      gsap.fromTo(card, { y: 40, opacity: 0 }, {
        y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: i * 0.15,
        scrollTrigger: { trigger: '#team', start: 'top 80%', toggleActions: 'play none none reverse' }
      });
    });

    /* Publications entrance */
    document.querySelectorAll('.pub-item').forEach((item, i) => {
      gsap.fromTo(item, { y: 20, opacity: 0 }, {
        y: 0, opacity: 1, duration: 0.6, ease: 'power3.out', delay: i * 0.08,
        scrollTrigger: { trigger: '#publications', start: 'top 75%', toggleActions: 'play none none reverse' }
      });
    });


    /* Advisor cards entrance */
    document.querySelectorAll('.advisor-card').forEach((card, i) => {
      gsap.fromTo(card, { y: 24, opacity: 0 }, {
        y: 0, opacity: 1, duration: 0.6, ease: 'power3.out', delay: 0.2 + i * 0.15,
        scrollTrigger: { trigger: '#advisor-grid', start: 'top 80%', toggleActions: 'play none none reverse' }
      });
    });
    /* Footer entrance */
    gsap.fromTo('.footer-vision', { y: 20, opacity: 0 }, {
      y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
      scrollTrigger: { trigger: '#footer', start: 'top 80%', toggleActions: 'play none none reverse' }
    });
    document.querySelectorAll('.footer-col').forEach((col, i) => {
      gsap.fromTo(col, { y: 40, opacity: 0 }, {
        y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.15 * i,
        scrollTrigger: { trigger: '#footer', start: 'top 80%', toggleActions: 'play none none reverse' }
      });
    });

    /* Fluid active control */
    const fluidSections = ['hero-section', 'gallery', 'philosophy'];
    const vis = { 'hero-section': true, gallery: false, philosophy: false };
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => { vis[e.target.id] = e.isIntersecting; });
      const anyVisible = fluidSections.some(id => vis[id]);
      if (typeof setFluidActive === 'function') setFluidActive(anyVisible);
    }, { threshold: 0.05 });
    fluidSections.forEach(id => {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    });

    /* Project detail overlay */
    const overlay = document.getElementById('project-detail');
    const detailBack = document.querySelector('.detail-back');

    function openDetail(id) {
      const p = PROJECTS.find(x => x.id === id);
      if (!p || !overlay) return;
      overlay.querySelector('.detail-id').textContent = `${p.id} / ${p.year}`;
      overlay.querySelector('.detail-stage').textContent = `${p.stage} · ${p.year}`;
      overlay.querySelector('.detail-title').textContent = p.title;
      overlay.querySelector('.detail-subtitle').textContent = p.subtitle;
      const metaWrap = overlay.querySelector('.detail-meta-rows');
      metaWrap.innerHTML = p.meta.map(m =>
        `<div style="display:flex;justify-content:space-between;gap:20px">
          <span class="mono" style="font-size:10px;letter-spacing:.25em;color:rgba(255,255,255,.55);text-transform:uppercase">${m.l}</span>
          <span style="font-size:12px;letter-spacing:.12em;color:rgba(255,255,255,.88);text-align:right">${m.v}</span>
        </div>`).join('');
      overlay.querySelector('.detail-paragraphs').innerHTML = p.body.map(b =>
        `<p style="font-size:15px;line-height:2;font-weight:300;color:rgba(255,255,255,.82)">${b}</p>`).join('');
      const img = overlay.querySelector('.detail-img');
      img.src = p.image;
      img.alt = p.title;
      img.style.display = 'block';
      overlay.classList.add('active');
      overlay.setAttribute('aria-hidden', 'false');
      overlay.scrollTop = 0;
      if (lenis) lenis.stop();
    }

    function closeDetail() {
      overlay.classList.remove('active');
      overlay.setAttribute('aria-hidden', 'true');
      if (lenis) lenis.start();
    }

    document.querySelectorAll('[data-id]').forEach(el => {
      el.addEventListener('click', () => openDetail(el.dataset.id));
    });
    if (detailBack) detailBack.addEventListener('click', closeDetail);
    overlay.addEventListener('keydown', e => { if (e.key === 'Escape') closeDetail(); });
  }

  document.readyState === 'loading'
    ? document.addEventListener('DOMContentLoaded', init)
    : init();
}());
